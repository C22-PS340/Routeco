package com.example.aplikasirouteco.model


import com.google.gson.annotations.SerializedName

data class Param(
    @SerializedName("description")
    val description: String,
    @SerializedName("id")
    val id: String,
    @SerializedName("times")
    val times: List<Time>,
    @SerializedName("type")
    val type: String
)
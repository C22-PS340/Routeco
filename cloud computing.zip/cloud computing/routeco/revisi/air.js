const http = require("https");
const options = {
	"method": "GET",
	"hostname": "api.ambeedata.com",
	"port": null,
	"path": "/latest/by-city?city=Bengaluru",
	"headers": {
		"x-api-key": "a733b18d765e9e978f5f4a2f3965bcd1a65ff858efdeebe6d5f8180511a68ecc",
		"Content-type": "application/json"
	}
};
const req = http.request(options, function (res) {
	const chunks = [];
	res.on("data", function (chunk) {
		chunks.push(chunk);
	});
	res.on("end", function () {
		const body = Buffer.concat(chunks);
		console.log(body.toString());
	});
});
req.end();
package com.example.aplikasirouteco.model


import com.google.gson.annotations.SerializedName

class RoutecoPolutionModel : ArrayList<RoutecoPolutionModelItem>()
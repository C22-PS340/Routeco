package com.example.aplikasirouteco.api

import com.example.aplikasirouteco.model.RoutecoWeatherModel
import io.reactivex.Single
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory

class RoutecoApiService {

    private val BASE_URL = "https://apibmkg-dot-routeco-352603.uw.r.appspot.com/"

    private val api = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
        .build()
        .create(RoutecoApi::class.java)

    fun getDataService(cityName: String): Single<RoutecoWeatherModel> {
        return api.getData(cityName)
    }

}
package com.example.aplikasirouteco.api

import com.example.aplikasirouteco.model.RoutecoWeatherModel
import io.reactivex.Single
import retrofit2.http.GET
import retrofit2.http.Query

interface RoutecoApi {

    //https://apibmkg-dot-routeco-352603.uw.r.appspot.com/weather/dki-jakarta/jakarta-selatan
    @GET("weather/dki-jakarta/jakarta-selatan")
    fun getData(
        @Query("") cityName: String
    ): Single<RoutecoWeatherModel>

}
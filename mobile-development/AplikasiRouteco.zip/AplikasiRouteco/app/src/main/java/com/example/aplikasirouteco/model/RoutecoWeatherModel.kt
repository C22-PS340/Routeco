package com.example.aplikasirouteco.model


import com.google.gson.annotations.SerializedName

data class RoutecoWeatherModel(
    @SerializedName("data")
    val `data`: Data,
    @SerializedName("message")
    val message: Any,
    @SerializedName("success")
    val success: Boolean,




)
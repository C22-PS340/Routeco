package com.example.aplikasirouteco.model


import com.google.gson.annotations.SerializedName

data class RoutecoPolutionModelItem(
    @SerializedName("categori")
    val categori: String,
    @SerializedName("co")
    val co: String,
    @SerializedName("critical")
    val critical: String,
    @SerializedName("max")
    val max: String,
    @SerializedName("no2")
    val no2: String,
    @SerializedName("o3")
    val o3: String,
    @SerializedName("pm10")
    val pm10: String,
    @SerializedName("so2")
    val so2: String,
    @SerializedName("tanggal")
    val tanggal: String,
    @SerializedName("")
    val x: String
)
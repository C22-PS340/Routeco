package com.example.aplikasirouteco.ui.settings

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import com.example.aplikasirouteco.R
import com.example.aplikasirouteco.databinding.ActivitySettingsBinding
import com.example.aplikasirouteco.ui.splash.SplashActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlin.system.exitProcess

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.apply {

            btnLanguageSetting.setOnClickListener {
                startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS))
            }

            btnLogout.setOnClickListener {
                finishAffinity()
            }
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        finishAffinity()
    }

}
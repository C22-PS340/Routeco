package com.example.aplikasirouteco.model


import com.google.gson.annotations.SerializedName

data class Time(
    @SerializedName("card")
    val card: String,
    @SerializedName("celcius")
    val celcius: String,
    @SerializedName("code")
    val code: String,
    @SerializedName("datetime")
    val datetime: String,
    @SerializedName("day")
    val day: String,
    @SerializedName("deg")
    val deg: String,
    @SerializedName("fahrenheit")
    val fahrenheit: String,
    @SerializedName("h")
    val h: String,
    @SerializedName("kph")
    val kph: String,
    @SerializedName("kt")
    val kt: String,
    @SerializedName("mph")
    val mph: String,
    @SerializedName("ms")
    val ms: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("sexa")
    val sexa: String,
    @SerializedName("type")
    val type: String,
    @SerializedName("value")
    val value: String
)
let mbAttr = 'Maps &copy; <a href="https://www.openstreetmap.org/">Open Street Map</a> contributors, ' +
            '<a href= "https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
            'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>';
let mbUrl= 'https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw';
let apiUrl = 'https://data.bmkg.go.id/DataMKG/MEWS/DigitalForecast/DigitalForecast-DKIJakarta.xml';
let light = L.tileLayer(mbUrl, {id: 'mapbox/light-v9', tileSize: 512, zoomOffset: -1, attribution: mbAttr});
let dark = L.tileLayer(mbUrl, {id: 'mapbox/dark-v9', tileSize: 512, zoomOffset: -1, attribution: mbAttr});
let markersLayers = new L.LayerGroup();
let maps = L.maps('maps',{layers:light}).setView([6.2088, 106.8456], 5);

let baseLayers = {
    "Light": light,
    "Dark": dark
};

L.control.Layers(baseLayers).addTo(maps);
let utc = 8;
let date = new moment();
let tanggal = document.querySelector('.tanggal');
let selectTanggal = document.querySelector('[name=select-tanggal]');
let nextDate;
let createSelect = false;
let selectOption = [];
let kodeCuaca = {
    '0' : ['Cerah (Clear Skies)', 'cerah.png'],
    '1' : ['Cerah Berawan (Partly Cloudy)', 'cerahberawan.png'],
    '3' : ['Berawan (Mostly Cloudy)','berawan.png'],
    '4' : ['Berawan Tebal (Overcast)', 'berawantebal.png'],
    '5' : ['Udara Kabur (Haze)', 'berangin.png'],
    '10' : ['Asap (Smoke)', 'asap.png'],
    '45' : ['Kabut (Fog)', 'kabut.png'],
    '60' : ['Hujan Ringan (Light Rain)', 'hujanringan.png'],
    '61': ['Hujan Sedang (Rain)', 'hujansedang.png'],
    '63' : ['Hujan Lebat (Heavy Rain)', 'hujanlebat.png'],
    '80' : ['Hujan Lokal (Isolated Shower)', 'hujanlokal.png'],
    '95' : ['Hujan Petir (Severe Thunderstorm)', 'hujanpetir.png'],
};

selectTanggal.addEventListener('change',()=>{
    console.log(selectTanggal.value);
    getData(selectTanggal.value);
});

getData(date);
async function getData(dateTime){
    markersLayers.clearLayers();
    dateTime = moment(dateTime).substract(utc, 'h');
    let response = await fetch(apiUrl);
    let xmlString = await response.text();
    let parse = new DOMParser();
    let xmlData = parse.parseFromString(xmlString, 'text/xml');
    let areas = xmlData.querySelectorAll('area');
    areas.forEach((area)=>{
        let lat = area.getAttribute('latitude');
        let lng = area.getAttribute('longitude');
        let prov = area.getAttribute('description');
        let weathers = area.querySelectorAll('parameter[id="weather"] timerange');
        let getTime = false;
        let posForecasting;
        
        let popUp = '<table width="190px">';
        weathers.forEach((weather,i)=>{
            let getDateTime = weather.getAttribute('datetime');
            let forecasting = weathers[i].querySelector('value').textContent;
            
            if(!selectOption.includes(getDateTime.substring(0,8))){
                selectOption.push(getDateTime.substring(0,8));
            }
            
            if(getDateTime.substring(0,8) == dateTime.format('YYYYMMDD')){
                popUp += '<tr>'+
                            '<td>'+convertTime(getDateTime.substring(8))+
                            '<td>:</td>'+
                            '<td><img style="width:40px; float:left" src="'+'assets/icon'+kodeCuaca[forecasting][1]+'"> '+
                            '<span style="position:relative;top:10px">'+kodeCuaca[forecasting][0]+'</span></td>'+
                            '</tr>';
            }

            if(getDateTime.substring(0,10)>=dateTime.format('YYYYMMDDHH') && getTime==false){
                posForecasting=i;
                nextDate=getDateTime;
                getTime=true;
            }
        });

        popUp += '</table>';

        let forecasting = weathers[posForecasting].querySelector('value').textContent;
        let iconUrl = 'assets/icon'+kodeCuaca[forecasting][1];
        let deskripsi = kodeCuaca[forecasting][0];

        let marker = L.marker([lat,lng],{
            icon: L.icon({
                iconUrl: iconUrl,
                iconSize: [50,50],
                iconAnchor: [25,25]
        })
        }).bindPopup('<strong>Kota Administrasi'+prov+'</strong><br>'+parseDate(nextDate)+'<br>Keterangan : '+deskripsi+popUp);
        marker.addTo(markersLayers);
        markersLayers.addTo(maps);
        tanggal.textContent = parseDate(nextDate);
    });

    if(createSelect==false){
        selectOption.forEach((getDate)=>{
            console.log(getDate);
            let option = moment(getDate).format('D MMMM YYYY');
            let value = moment(getDate).format('YYYYMMDD');
            if (value==moment(date).format('YYYY-MM-DD HH')){
                value = moment(date).format('YYYY-MM-DD HH');
            }
            else{
                value = moment(getDate).format('YYYY-MM-DD')+' 0'+utc;
            }
            let newOption=new Option(option, value);
            selectTanggal.add(newOption);

        });
        selectTanggal.value = moment(date).format('YYYY-MM-DD HH');
        createSelect=true;
    }
}

function convertTime(time){
    if(time=='0000'){
        return 'Pagi';
    }
    else if(time=='0600'){
        return 'Siang';
    }
    else if(time=='1200'){
        return 'Sore';
    }
    else if(time=='1800'){
        return 'Dini Hari';
    }
    else{
        return 'Error';
    }
}

function parseData(date){
    let tahun = date.substr(0,4);
    let bulan = date.substr(4,2);
    let tanggal = date.substr(6,2);
    let jam = date.substr(8,2);
    let menit = date.substr(10,2);
    let setTanggal = tahun+'-'+bulan+'-'+tanggal+''+jam+':'+menit+':00';
    return moment(setTanggal).add(utc,'h').format('DD MM YYYY HH:mm')+' WITA';
}
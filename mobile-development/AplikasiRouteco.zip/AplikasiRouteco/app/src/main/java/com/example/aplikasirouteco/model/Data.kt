package com.example.aplikasirouteco.model


import com.google.gson.annotations.SerializedName

data class Data(
    @SerializedName("coordinate")
    val coordinate: String,
    @SerializedName("description")
    val description: String,
    @SerializedName("domain")
    val domain: String,
    @SerializedName("id")
    val id: String,
    @SerializedName("latitude")
    val latitude: String,
    @SerializedName("level")
    val level: String,
    @SerializedName("longitude")
    val longitude: String,
    @SerializedName("params")
    val params: List<Param>,
    @SerializedName("region")
    val region: String,
    @SerializedName("tags")
    val tags: String,
    @SerializedName("type")
    val type: String
)